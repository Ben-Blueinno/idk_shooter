	

	Pixel Sidescroller Character

	Created by dylestorm (www.livingtheindie.com)

			------------------------------

	Follow me on Twitter:
	https://twitter.com/livingtheindie
